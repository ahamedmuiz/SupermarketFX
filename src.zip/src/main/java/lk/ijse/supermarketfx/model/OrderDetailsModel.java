package lk.ijse.supermarketfx.model;

/**
 * --------------------------------------------
 * Author: Shamodha Sahan
 * GitHub: https://github.com/shamodhas
 * Website: https://shamodha.com
 * --------------------------------------------
 * Created: 4/24/2025 9:32 AM
 * Project: SupermarketFX
 * --------------------------------------------
 **/

public class OrderDetailsModel {
}
