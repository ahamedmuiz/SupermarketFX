package lk.ijse.supermarketfx.controller;

/**
 * --------------------------------------------
 * Author: Shamodha Sahan
 * GitHub: https://github.com/shamodhas
 * Website: https://shamodha.com
 * --------------------------------------------
 * Created: 4/3/2025 10:30 AM
 * Project: SupermarketFX
 * --------------------------------------------
 **/

public class ItemPageController {
}
