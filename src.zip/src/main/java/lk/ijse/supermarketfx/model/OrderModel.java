package lk.ijse.supermarketfx.model;


public class OrderModel {


}
